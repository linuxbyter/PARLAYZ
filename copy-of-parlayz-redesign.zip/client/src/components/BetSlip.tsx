import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import FloatingParticles from "./FloatingParticles";

type PoolMode = "fixed" | "p2p" | "mini";

interface BetSlipProps {
  onBet?: (stake: number, poolMode: PoolMode) => void;
}

export default function BetSlip({ onBet }: BetSlipProps) {
  const [poolMode, setPoolMode] = useState<PoolMode>("fixed");
  const [selectedSide, setSelectedSide] = useState("yes");
  const [stake, setStake] = useState("100");
  const [showParticles, setShowParticles] = useState(false);
  const [isPlacingBet, setIsPlacingBet] = useState(false);

  // Mini Pool specific state
  const [showMiniPoolForm, setShowMiniPoolForm] = useState(false);
  const [miniPoolName, setMiniPoolName] = useState("");
  const [miniPoolMembers, setMiniPoolMembers] = useState(5);

  const stakeNumber = parseFloat(stake) || 0;
  const isValidStake = stakeNumber >= 0.01 && stakeNumber <= 10000;

  // Calculate payout based on pool mode
  const calculatePayout = () => {
    if (!isValidStake) return 0;

    if (poolMode === "fixed") {
      // Fixed Odds: 1.85 for YES, 2.15 for NO
      const odds = selectedSide === "yes" ? 1.85 : 2.15;
      return stakeNumber * odds;
    } else if (poolMode === "p2p") {
      // P2P: Dynamic odds based on pool flow (mock: 1.67 for YES, 2.33 for NO)
      const odds = selectedSide === "yes" ? 1.67 : 2.33;
      return stakeNumber * odds;
    } else {
      // Mini Pool: Same as P2P but within group
      const odds = selectedSide === "yes" ? 1.67 : 2.33;
      return stakeNumber * odds;
    }
  };

  const platformFee = isValidStake ? stakeNumber * 0.03 : 0;
  const potentialPayout = calculatePayout() - platformFee;

  const handlePlaceBet = async () => {
    if (!isValidStake) {
      toast.error("Please enter a valid stake between $0.01 and $10,000");
      return;
    }

    if (poolMode === "mini" && !miniPoolName.trim()) {
      toast.error("Please enter a mini pool name");
      return;
    }

    setIsPlacingBet(true);
    setShowParticles(true);

    setTimeout(() => {
      onBet?.(stakeNumber, poolMode);
      const poolLabel =
        poolMode === "fixed"
          ? "Fixed Odds"
          : poolMode === "p2p"
            ? "Peer-to-Peer"
            : `Mini Pool "${miniPoolName}"`;
      toast.success(
        `Bet placed: KSh ${stakeNumber.toFixed(2)} on ${selectedSide.toUpperCase()} (${poolLabel})`
      );
      setIsPlacingBet(false);
      setShowParticles(false);
      setShowMiniPoolForm(false);
      setMiniPoolName("");
    }, 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full bg-card border border-border rounded-2xl p-6 space-y-6"
      style={{
        boxShadow: "inset 0 1px 0 rgba(201, 168, 76, 0.06)",
      }}
    >
      <FloatingParticles trigger={showParticles} />

      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold text-foreground">Bet Slip</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Choose your pool and place your bet
        </p>
      </div>

      {/* Pool Mode Selection */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-foreground">Pool Mode</label>
        <div className="grid grid-cols-3 gap-3">
          {[
            { id: "fixed", label: "Fixed Odds", desc: "Against house" },
            { id: "p2p", label: "Peer-to-Peer", desc: "vs other users" },
            { id: "mini", label: "Mini Pool", desc: "Private group" },
          ].map((mode) => (
            <motion.button
              key={mode.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                setPoolMode(mode.id as PoolMode);
                if (mode.id === "mini") setShowMiniPoolForm(true);
                else setShowMiniPoolForm(false);
              }}
              className={`p-3 rounded-lg border transition-all text-center ${
                poolMode === mode.id
                  ? "border-primary bg-primary/10 text-foreground"
                  : "border-border text-muted-foreground hover:border-primary/50"
              }`}
            >
              <div className="text-sm font-medium">{mode.label}</div>
              <div className="text-xs text-muted-foreground">{mode.desc}</div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Mini Pool Creation Form */}
      {poolMode === "mini" && showMiniPoolForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="space-y-3 p-4 bg-popover rounded-lg border border-border"
        >
          <div>
            <label className="text-sm font-medium text-foreground">
              Pool Name
            </label>
            <Input
              placeholder="e.g., Westlands Boys"
              value={miniPoolName}
              onChange={(e) => setMiniPoolName(e.target.value)}
              className="mt-2 bg-input border-border text-foreground"
            />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground">
              Max Members: {miniPoolMembers}
            </label>
            <input
              type="range"
              min="2"
              max="10"
              value={miniPoolMembers}
              onChange={(e) => setMiniPoolMembers(parseInt(e.target.value))}
              className="w-full mt-2"
            />
            <p className="text-xs text-muted-foreground mt-1">
              You'll get a shareable link after creating the pool
            </p>
          </div>
        </motion.div>
      )}

      {/* Pool Info */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="p-4 bg-popover rounded-lg border border-border space-y-2"
      >
        {poolMode === "fixed" && (
          <>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Fixed Odds (YES)</span>
              <span className="text-primary font-mono">1.85</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Fixed Odds (NO)</span>
              <span className="text-destructive font-mono">2.15</span>
            </div>
          </>
        )}
        {poolMode === "p2p" && (
          <>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                P2P Pool Size (YES)
              </span>
              <span className="text-primary font-mono">KSh 45,000</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                P2P Pool Size (NO)
              </span>
              <span className="text-destructive font-mono">KSh 22,500</span>
            </div>
            <p className="text-xs text-muted-foreground pt-2 border-t border-border">
              Odds adjust based on total pool flow. Your odds will be calculated
              at bet placement.
            </p>
          </>
        )}
        {poolMode === "mini" && (
          <>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Pool Type</span>
              <span className="text-foreground font-medium">Private Group</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Max Members</span>
              <span className="text-foreground font-mono">{miniPoolMembers}</span>
            </div>
            <p className="text-xs text-muted-foreground pt-2 border-t border-border">
              Winnings split proportionally among winners in your group. Stakes
              also count toward public market volume.
            </p>
          </>
        )}
      </motion.div>

      {/* Side Selection */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-foreground">
          Pick a Side
        </label>
        <div className="grid grid-cols-2 gap-3">
          {[
            { id: "yes", label: "YES", color: "primary" },
            { id: "no", label: "NO", color: "destructive" },
          ].map((side) => (
            <motion.button
              key={side.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedSide(side.id)}
              className={`py-3 px-4 rounded-lg border font-semibold transition-all ${
                selectedSide === side.id
                  ? `bg-${side.color} text-${side.color}-foreground border-${side.color}`
                  : `border-border text-muted-foreground hover:border-${side.color}/50`
              }`}
            >
              {side.label}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Stake Input */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-foreground">
          Your Stake (KSh)
        </label>
        <Input
          type="number"
          placeholder="100"
          value={stake}
          onChange={(e) => setStake(e.target.value)}
          min="0.01"
          max="10000"
          step="0.01"
          className="bg-input border-border text-foreground font-mono"
        />
        {!isValidStake && stake && (
          <p className="text-xs text-destructive">
            {parseFloat(stake) < 0.01
              ? "Minimum stake is KSh 0.01"
              : "Maximum stake is KSh 10,000"}
          </p>
        )}
      </div>

      {/* Payout Calculation */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="p-4 bg-popover rounded-lg border border-border space-y-2"
      >
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Your Stake</span>
          <span className="text-foreground font-mono">
            KSh {stakeNumber.toFixed(2)}
          </span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Platform Fee (3%)</span>
          <span className="text-destructive font-mono">
            -KSh {platformFee.toFixed(2)}
          </span>
        </div>
        <div className="border-t border-border pt-2 flex justify-between">
          <span className="text-foreground font-semibold">Est. Payout</span>
          <span className="text-primary font-mono font-bold">
            KSh {potentialPayout.toFixed(2)}
          </span>
        </div>
      </motion.div>

      {/* Place Bet Button */}
      <motion.button
        whileHover={{ scale: isValidStake ? 1.02 : 1 }}
        whileTap={{ scale: isValidStake ? 0.98 : 1 }}
        onClick={handlePlaceBet}
        disabled={!isValidStake || isPlacingBet}
        className={`w-full py-3 px-4 rounded-lg font-semibold transition-all ${
          isValidStake
            ? "bg-primary text-primary-foreground hover:opacity-90 cursor-pointer"
            : "bg-muted text-muted-foreground cursor-not-allowed opacity-50"
        }`}
      >
        {isPlacingBet ? "Placing Bet..." : "Place Bet"}
      </motion.button>

      {/* Disclaimer */}
      <p className="text-xs text-muted-foreground text-center">
        By placing a bet, you agree to our terms. Bets are final once placed.
      </p>
    </motion.div>
  );
}
