import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Bell, Menu, Search, LogOut } from "lucide-react";
import { motion } from "framer-motion";
import { getLoginUrl } from "@/const";
import { useApp } from "@/contexts/AppContext";

const categories = ["Sports", "Crypto", "Politics", "Tech", "Meme"];

export default function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const { sidebarOpen, setSidebarOpen, userBalance } = useApp();

  const handleLogout = async () => {
    await logout();
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-2"
        >
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">P</span>
          </div>
          <span className="hidden sm:inline font-semibold text-lg">Parlayz</span>
        </motion.div>

        {/* Category Navigation - Desktop */}
        <nav className="hidden md:flex items-center gap-6 flex-1 mx-8">
          {categories.map((cat) => (
            <motion.button
              key={cat}
              whileHover={{ color: "#C9A84C" }}
              className="text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              {cat}
            </motion.button>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          {/* Search Icon */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 hover:bg-card rounded-lg transition-colors"
          >
            <Search className="w-5 h-5" />
          </motion.button>

          {/* Notifications */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 hover:bg-card rounded-lg transition-colors relative"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
          </motion.button>

          {/* Wallet Balance */}
          {isAuthenticated && (
            <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-popover rounded-lg border border-border">
              <span className="text-xs text-muted-foreground">Balance</span>
              <span className="font-mono font-semibold text-primary">
                KSh {userBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          )}

          {/* User Avatar / Auth */}
          {isAuthenticated ? (
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="flex items-center gap-2"
            >
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center cursor-pointer hover:ring-2 ring-primary/50 transition-all">
                <span className="text-primary-foreground font-bold text-sm">
                  {user?.name?.charAt(0).toUpperCase() || "U"}
                </span>
              </div>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleLogout}
                className="p-2 hover:bg-card rounded-lg transition-colors"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </motion.button>
            </motion.div>
          ) : (
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href={getLoginUrl()}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-opacity"
            >
              Sign In
            </motion.a>
          )}

          {/* Mobile Menu Toggle */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="md:hidden p-2 hover:bg-card rounded-lg transition-colors"
          >
            <Menu className="w-5 h-5" />
          </motion.button>
        </div>
      </div>


    </header>
  );
}
