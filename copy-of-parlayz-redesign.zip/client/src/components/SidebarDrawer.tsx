import { motion, AnimatePresence } from "framer-motion";
import { X, LogOut, Settings, HelpCircle } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useApp } from "@/contexts/AppContext";

export default function SidebarDrawer() {
  const { user, isAuthenticated, logout } = useAuth();
  const { sidebarOpen, setSidebarOpen, userBalance } = useApp();

  const onClose = () => setSidebarOpen(false);

  const handleLogout = async () => {
    await logout();
    onClose();
  };

  return (
    <AnimatePresence>
      {sidebarOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 w-72 bg-card border-l border-border z-50 md:hidden overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="font-semibold">Menu</h2>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={onClose}
                className="p-2 hover:bg-background rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>

            {/* User Info */}
            {isAuthenticated && (
              <div className="p-4 border-b border-border">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-primary-foreground font-bold">
                      {user?.name?.charAt(0).toUpperCase() || "U"}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{user?.name}</p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                </div>
                <div className="bg-popover rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">Balance</p>
                  <p className="font-mono font-bold text-primary text-lg">
                    KSh {userBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>
              </div>
            )}

            {/* Menu Items */}
            <nav className="p-4 space-y-2">
              {isAuthenticated && (
                <>
                  <motion.a
                    href="/wagers"
                    whileHover={{ x: 4 }}
                    onClick={onClose}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-background transition-colors"
                  >
                    <span>My Wagers</span>
                  </motion.a>
                  <motion.a
                    href="/wallet"
                    whileHover={{ x: 4 }}
                    onClick={onClose}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-background transition-colors"
                  >
                    <span>Wallet</span>
                  </motion.a>
                  <motion.a
                    href="/leaderboard"
                    whileHover={{ x: 4 }}
                    onClick={onClose}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-background transition-colors"
                  >
                    <span>Leaderboard</span>
                  </motion.a>
                </>
              )}

              <motion.a
                href="/docs"
                whileHover={{ x: 4 }}
                onClick={onClose}
                className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-background transition-colors"
              >
                <span>Documentation</span>
              </motion.a>

              <motion.button
                whileHover={{ x: 4 }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-background transition-colors"
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </motion.button>

              <motion.button
                whileHover={{ x: 4 }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-background transition-colors"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Help</span>
              </motion.button>
            </nav>

            {/* Logout */}
            {isAuthenticated && (
              <div className="absolute bottom-4 left-4 right-4">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-destructive/10 hover:bg-destructive/20 text-destructive rounded-lg transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </motion.button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
