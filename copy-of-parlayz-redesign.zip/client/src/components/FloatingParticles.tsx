import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface Particle {
  id: number;
  x: number;
  y: number;
  type: "coin" | "cash";
}

interface FloatingParticlesProps {
  trigger?: boolean;
  onComplete?: () => void;
}

export default function FloatingParticles({
  trigger = false,
  onComplete,
}: FloatingParticlesProps) {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    if (!trigger) return;

    const newParticles: Particle[] = Array.from({ length: 8 }, (_, i) => ({
      id: i,
      x: Math.random() * 100 - 50,
      y: Math.random() * 100 - 50,
      type: i % 2 === 0 ? "coin" : "cash",
    }));

    setParticles(newParticles);

    const timer = setTimeout(() => {
      setParticles([]);
      onComplete?.();
    }, 1500);

    return () => clearTimeout(timer);
  }, [trigger, onComplete]);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          initial={{
            x: 0,
            y: 0,
            opacity: 1,
            scale: 1,
          }}
          animate={{
            x: particle.x * 100,
            y: particle.y * 100,
            opacity: 0,
            scale: 0,
          }}
          transition={{
            duration: 1.5,
            ease: "easeOut",
          }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
        >
          {particle.type === "coin" ? (
            <div className="w-6 h-6 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-xs font-bold">
              $
            </div>
          ) : (
            <div className="w-8 h-4 bg-gradient-to-r from-primary to-accent rounded text-xs font-bold text-background flex items-center justify-center">
              $
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}
