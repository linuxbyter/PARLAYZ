import { useState } from "react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { motion } from "framer-motion";

interface PriceChartProps {
  data: Array<{
    time: string;
    price: number;
  }>;
  isLoading?: boolean;
}

const timeFilters = ["1m", "5m", "15m", "1h", "ALL"];

export default function PriceChart({ data, isLoading = false }: PriceChartProps) {
  const [selectedFilter, setSelectedFilter] = useState("1h");

  if (isLoading) {
    return (
      <div className="w-full h-80 bg-card rounded-lg border border-border flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading chart...</div>
      </div>
    );
  }

  return (
    <div className="w-full bg-card rounded-lg border border-border p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-sm text-muted-foreground mb-1">UP PROBABILITY</p>
          <p className="text-3xl font-mono font-bold text-primary">67.5%</p>
        </div>
        <div className="flex gap-2">
          {timeFilters.map((filter) => (
            <motion.button
              key={filter}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedFilter(filter)}
              className={`px-3 py-1 rounded text-xs font-semibold transition-all ${
                selectedFilter === filter
                  ? "bg-primary text-background"
                  : "bg-background border border-border text-foreground hover:border-primary/50"
              }`}
            >
              {filter}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="rgb(0, 255, 0)" stopOpacity={0.3} />
              <stop offset="95%" stopColor="rgb(0, 255, 0)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          <XAxis
            dataKey="time"
            stroke="rgba(255,255,255,0.5)"
            style={{ fontSize: "12px" }}
          />
          <YAxis
            stroke="rgba(255,255,255,0.5)"
            style={{ fontSize: "12px" }}
            domain={["dataMin - 0.1", "dataMax + 0.1"]}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "rgba(13, 13, 13, 0.95)",
              border: "1px solid rgba(255,255,255,0.2)",
              borderRadius: "8px",
            }}
            labelStyle={{ color: "rgb(0, 255, 0)" }}
            formatter={(value) => `$${(value as number).toFixed(2)}`}
          />
          <Area
            type="monotone"
            dataKey="price"
            stroke="rgb(0, 255, 0)"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#colorPrice)"
            dot={{ fill: "rgb(0, 255, 0)", r: 4 }}
            activeDot={{ r: 6 }}
          />
        </AreaChart>
      </ResponsiveContainer>

      {/* Reference Line */}
      <div className="mt-4 flex items-center gap-2">
        <div className="flex-1 h-px bg-gradient-to-r from-muted via-muted to-transparent"></div>
        <span className="text-xs text-muted-foreground">50% Reference</span>
        <div className="flex-1 h-px bg-gradient-to-l from-muted via-muted to-transparent"></div>
      </div>
    </div>
  );
}
