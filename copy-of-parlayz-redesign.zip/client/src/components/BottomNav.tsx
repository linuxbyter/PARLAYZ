import { motion } from "framer-motion";
import { Home, TrendingUp, Search, Wallet } from "lucide-react";
import { useLocation } from "wouter";

const navItems = [
  { icon: Home, label: "Browse", path: "/" },
  { icon: TrendingUp, label: "Live", path: "/live" },
  { icon: Search, label: "Search", path: "/search" },
  { icon: Wallet, label: "Wagers", path: "/wagers" },
];

export default function BottomNav() {
  const [location, navigate] = useLocation();

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 md:hidden border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
    >
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const isActive = location === item.path;
          return (
            <motion.button
              key={item.path}
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center gap-1 px-4 py-2 transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <item.icon className="w-6 h-6" />
              <span className="text-xs">{item.label}</span>
              {isActive && (
                <motion.div
                  layoutId="activeNav"
                  className="w-1 h-1 bg-primary rounded-full"
                />
              )}
            </motion.button>
          );
        })}
      </div>
    </motion.nav>
  );
}
