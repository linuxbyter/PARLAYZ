import { motion } from "framer-motion";
import { TrendingUp, TrendingDown } from "lucide-react";

export type MarketType = "binary" | "multi" | "duel";

interface MarketCardProps {
  type: MarketType;
  title: string;
  category: string;
  volume: number;
  odds?: {
    yes: number;
    no: number;
  };
  options?: Array<{
    label: string;
    percentage: number;
  }>;
  duelInfo?: {
    player1: string;
    player2: string;
  };
  priceChange?: number;
  isLive?: boolean;
  onClick?: () => void;
}

export default function MarketCard({
  type,
  title,
  category,
  volume,
  odds,
  options,
  duelInfo,
  priceChange = 0,
  isLive = true,
  onClick,
}: MarketCardProps) {
  const calculatePercentage = (value: number, total: number) => {
    return ((value / total) * 100).toFixed(1);
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="bg-card border border-border rounded-2xl p-6 cursor-pointer transition-all hover:border-primary/40 group"
      style={{
        boxShadow: "inset 0 1px 0 rgba(201, 168, 76, 0.06)",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).style.boxShadow = 
          "inset 0 1px 0 rgba(201, 168, 76, 0.06), 0 0 20px rgba(201, 168, 76, 0.15)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLElement).style.boxShadow = 
          "inset 0 1px 0 rgba(201, 168, 76, 0.06)";
      }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            {category}
          </span>
          {isLive && (
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 bg-destructive rounded-full animate-pulse"></span>
              <span className="text-xs text-destructive font-semibold">LIVE</span>
            </div>
          )}
        </div>
        {priceChange !== 0 && (
          <div
            className={`flex items-center gap-1 ${priceChange > 0 ? "text-primary" : "text-destructive"}`}
          >
            {priceChange > 0 ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            <span className="text-xs font-semibold font-mono">
              {Math.abs(priceChange)}%
            </span>
          </div>
        )}
      </div>

      {/* Title */}
      <h3 className="text-base font-semibold mb-4 line-clamp-2 text-foreground">
        {title}
      </h3>

      {/* Content based on type */}
      {type === "binary" && odds && (
        <div className="space-y-3 mb-4">
          <div className="grid grid-cols-2 gap-3">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-primary/5 border border-primary/20 rounded-lg px-3 py-3 text-center"
            >
              <p className="text-xs text-muted-foreground mb-1 font-medium">
                YES
              </p>
              <p className="font-mono font-bold text-primary text-lg">
                {odds.yes.toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {calculatePercentage(odds.yes, odds.yes + odds.no)}%
              </p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-destructive/5 border border-destructive/20 rounded-lg px-3 py-3 text-center"
            >
              <p className="text-xs text-muted-foreground mb-1 font-medium">
                NO
              </p>
              <p className="font-mono font-bold text-destructive text-lg">
                {odds.no.toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {calculatePercentage(odds.no, odds.yes + odds.no)}%
              </p>
            </motion.div>
          </div>
          {/* Progress bar */}
          <div className="flex h-2 gap-0 rounded-full overflow-hidden bg-muted">
            <motion.div
              initial={{ width: 0 }}
              animate={{
                width: `${calculatePercentage(odds.yes, odds.yes + odds.no)}%`,
              }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="bg-primary rounded-l-full"
            />
            <motion.div
              initial={{ width: 0 }}
              animate={{
                width: `${calculatePercentage(odds.no, odds.yes + odds.no)}%`,
              }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="bg-destructive rounded-r-full"
            />
          </div>
        </div>
      )}

      {type === "multi" && options && (
        <div className="space-y-2 mb-4">
          {options.slice(0, 3).map((opt, idx) => (
            <motion.div
              key={idx}
              whileHover={{ x: 4 }}
              className="flex items-center justify-between p-2 rounded-lg hover:bg-popover transition-colors"
            >
              <span className="text-sm text-foreground">{opt.label}</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${opt.percentage}%` }}
                    transition={{ duration: 0.5 }}
                    className="h-full bg-primary"
                  />
                </div>
                <span className="text-xs font-mono text-muted-foreground w-8 text-right">
                  {opt.percentage}%
                </span>
              </div>
            </motion.div>
          ))}
          {options.length > 3 && (
            <div className="text-xs text-muted-foreground text-center pt-1">
              +{options.length - 3} more
            </div>
          )}
        </div>
      )}

      {type === "duel" && duelInfo && (
        <div className="space-y-3 mb-4">
          <div className="grid grid-cols-2 gap-3">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-primary/5 border border-primary/20 rounded-lg px-3 py-3 text-center"
            >
              <p className="text-xs text-muted-foreground mb-1 font-medium">
                {duelInfo.player1}
              </p>
              <p className="font-mono font-bold text-primary text-lg">1.92</p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-destructive/5 border border-destructive/20 rounded-lg px-3 py-3 text-center"
            >
              <p className="text-xs text-muted-foreground mb-1 font-medium">
                {duelInfo.player2}
              </p>
              <p className="font-mono font-bold text-destructive text-lg">
                1.92
              </p>
            </motion.div>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground">Head-to-Head Duel</p>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-muted-foreground pt-4 border-t border-border">
        <span className="font-mono">
          KSh {(volume / 1000).toFixed(1)}K Vol.
        </span>
        <motion.span whileHover={{ x: 2 }} className="cursor-pointer">
          View →
        </motion.span>
      </div>
    </motion.div>
  );
}
