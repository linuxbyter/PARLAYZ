import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Copy, Share2, Users } from "lucide-react";

interface MiniPool {
  id: string;
  name: string;
  maxMembers: number;
  currentMembers: number;
  members: Array<{
    id: string;
    name: string;
    side: "yes" | "no";
    stake: number;
  }>;
  createdAt: Date;
  shareLink: string;
}

interface MiniPoolManagerProps {
  onPoolCreated?: (pool: MiniPool) => void;
  onPoolJoined?: (pool: MiniPool) => void;
}

export default function MiniPoolManager({
  onPoolCreated,
  onPoolJoined,
}: MiniPoolManagerProps) {
  const [pools, setPools] = useState<MiniPool[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showJoinForm, setShowJoinForm] = useState(false);
  const [poolName, setPoolName] = useState("");
  const [maxMembers, setMaxMembers] = useState(5);
  const [joinCode, setJoinCode] = useState("");

  const generateShareLink = () => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `https://parlayz.app/join/${code}`;
  };

  const generatePoolId = () => {
    return `pool_${Date.now()}_${Math.random().toString(36).substring(7)}`;
  };

  const handleCreatePool = () => {
    if (!poolName.trim()) {
      toast.error("Please enter a pool name");
      return;
    }

    const newPool: MiniPool = {
      id: generatePoolId(),
      name: poolName,
      maxMembers,
      currentMembers: 1,
      members: [
        {
          id: "user_current",
          name: "You",
          side: "yes" as const,
          stake: 100,
        },
      ],
      createdAt: new Date(),
      shareLink: generateShareLink(),
    };

    setPools([...pools, newPool]);
    onPoolCreated?.(newPool);

    toast.success(`Mini pool "${poolName}" created! Share link copied.`);
    setPoolName("");
    setMaxMembers(5);
    setShowCreateForm(false);

    // Copy link to clipboard
    navigator.clipboard.writeText(newPool.shareLink);
  };

  const handleJoinPool = () => {
    if (!joinCode.trim()) {
      toast.error("Please enter a pool code");
      return;
    }

    // Mock: Find pool by code
    const poolToJoin = pools[0]; // In real app, look up by code
    if (!poolToJoin) {
      toast.error("Pool not found");
      return;
    }

    if (poolToJoin.currentMembers >= poolToJoin.maxMembers) {
      toast.error("Pool is full");
      return;
    }

        const updatedPool: MiniPool = {
          ...poolToJoin,
          currentMembers: poolToJoin.currentMembers + 1,
          members: [
            ...poolToJoin.members,
            {
              id: `user_${Date.now()}`,
              name: "New Member",
              side: "no" as const,
              stake: 100,
            },
          ],
        };

    setPools(pools.map((p) => (p.id === poolToJoin.id ? updatedPool : p)));
    onPoolJoined?.(updatedPool);

    toast.success(`Joined pool "${poolToJoin.name}"!`);
    setJoinCode("");
    setShowJoinForm(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full space-y-6"
    >
      {/* Create/Join Buttons */}
      <div className="grid grid-cols-2 gap-4">
        <Button
          onClick={() => {
            setShowCreateForm(!showCreateForm);
            setShowJoinForm(false);
          }}
          className="bg-primary text-primary-foreground"
        >
          Create Pool
        </Button>
        <Button
          onClick={() => {
            setShowJoinForm(!showJoinForm);
            setShowCreateForm(false);
          }}
          variant="outline"
        >
          Join Pool
        </Button>
      </div>

      {/* Create Pool Form */}
      {showCreateForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="p-4 bg-popover rounded-lg border border-border space-y-4"
        >
          <div>
            <label className="text-sm font-medium text-foreground">
              Pool Name
            </label>
            <Input
              placeholder="e.g., Westlands Crew"
              value={poolName}
              onChange={(e) => setPoolName(e.target.value)}
              className="mt-2 bg-input border-border text-foreground"
            />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground">
              Max Members: {maxMembers}
            </label>
            <input
              type="range"
              min="2"
              max="10"
              value={maxMembers}
              onChange={(e) => setMaxMembers(parseInt(e.target.value))}
              className="w-full mt-2"
            />
          </div>
          <Button
            onClick={handleCreatePool}
            className="w-full bg-primary text-primary-foreground"
          >
            Create Pool
          </Button>
        </motion.div>
      )}

      {/* Join Pool Form */}
      {showJoinForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="p-4 bg-popover rounded-lg border border-border space-y-4"
        >
          <div>
            <label className="text-sm font-medium text-foreground">
              Pool Code
            </label>
            <Input
              placeholder="e.g., ABC123"
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              className="mt-2 bg-input border-border text-foreground font-mono"
            />
          </div>
          <Button
            onClick={handleJoinPool}
            className="w-full bg-primary text-primary-foreground"
          >
            Join Pool
          </Button>
        </motion.div>
      )}

      {/* Active Pools List */}
      {pools.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-foreground">
            Your Mini Pools
          </h3>
          {pools.map((pool) => (
            <motion.div
              key={pool.id}
              whileHover={{ scale: 1.02 }}
              className="p-4 bg-card border border-border rounded-lg space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-semibold text-foreground">{pool.name}</h4>
                  <p className="text-xs text-muted-foreground">
                    {pool.currentMembers} / {pool.maxMembers} members
                  </p>
                </div>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    navigator.clipboard.writeText(pool.shareLink);
                    toast.success("Share link copied!");
                  }}
                  className="p-2 hover:bg-popover rounded-lg transition-colors"
                >
                  <Share2 className="w-4 h-4 text-primary" />
                </motion.button>
              </div>

              {/* Members */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>Members</span>
                </div>
                {pool.members.map((member) => (
                  <div
                    key={member.id}
                    className="flex items-center justify-between text-sm p-2 bg-popover rounded"
                  >
                    <span className="text-foreground">{member.name}</span>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-semibold ${
                          member.side === "yes" ? "text-primary" : "text-destructive"
                        }`}
                      >
                        {member.side.toUpperCase()}
                      </span>
                      <span className="text-xs text-muted-foreground font-mono">
                        KSh {member.stake}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Copy Link */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                onClick={() => {
                  navigator.clipboard.writeText(pool.shareLink);
                  toast.success("Link copied to clipboard!");
                }}
                className="w-full flex items-center justify-center gap-2 p-2 bg-primary/10 border border-primary/20 rounded-lg text-primary text-sm font-medium hover:bg-primary/20 transition-colors"
              >
                <Copy className="w-4 h-4" />
                Copy Share Link
              </motion.button>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
