import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AppProvider } from "./contexts/AppContext";
import Home from "./pages/Home";
import MarketDetail from "./pages/MarketDetail";
import MyWagers from "./pages/MyWagers";
import Wallet from "./pages/Wallet";
import Leaderboard from "./pages/Leaderboard";
import Docs from "./pages/Docs";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/market/:id"} component={MarketDetail} />
      <Route path={"/wagers"} component={MyWagers} />
      <Route path={"/wallet"} component={Wallet} />
      <Route path={"/leaderboard"} component={Leaderboard} />
      <Route path={"/docs"} component={Docs} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <AppProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AppProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
