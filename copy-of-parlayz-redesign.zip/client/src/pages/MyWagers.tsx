import { useState } from "react";
import { motion } from "framer-motion";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import PageTransition from "@/components/PageTransition";
import { TrendingUp, TrendingDown } from "lucide-react";

interface Wager {
  id: string;
  market: string;
  category: string;
  side: "yes" | "no";
  stake: number;
  odds: number;
  payout: number;
  status: "active" | "settled" | "cancelled";
  result?: "won" | "lost";
  timestamp: string;
}

const mockWagers: Wager[] = [
  {
    id: "1",
    market: "Will Manchester United win?",
    category: "Sports",
    side: "yes",
    stake: 250,
    odds: 1.85,
    payout: 462.5,
    status: "settled",
    result: "won",
    timestamp: "2026-04-20 14:32",
  },
  {
    id: "2",
    market: "Bitcoin reach $100k?",
    category: "Crypto",
    side: "no",
    stake: 150,
    odds: 2.15,
    payout: 0,
    status: "active",
    timestamp: "2026-04-20 12:15",
  },
  {
    id: "3",
    market: "World Cup Winner",
    category: "Sports",
    side: "yes",
    stake: 100,
    odds: 3.5,
    payout: 0,
    status: "active",
    timestamp: "2026-04-19 10:45",
  },
  {
    id: "4",
    market: "Ethereum flip Bitcoin?",
    category: "Crypto",
    side: "no",
    stake: 200,
    odds: 1.8,
    payout: 0,
    status: "settled",
    result: "lost",
    timestamp: "2026-04-18 16:20",
  },
  {
    id: "5",
    market: "Kenya election outcome",
    category: "Politics",
    side: "yes",
    stake: 75,
    odds: 2.25,
    payout: 0,
    status: "cancelled",
    timestamp: "2026-04-17 09:30",
  },
];

type FilterStatus = "all" | "active" | "settled" | "cancelled";

export default function MyWagers() {
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("all");

  const filteredWagers = mockWagers.filter(
    (w) => filterStatus === "all" || w.status === filterStatus
  );

  const calculatePnL = (wager: Wager) => {
    if (wager.status === "settled" && wager.result === "won") {
      return wager.payout - wager.stake;
    } else if (wager.status === "settled" && wager.result === "lost") {
      return -wager.stake;
    }
    return 0;
  };

  const totalStaked = filteredWagers.reduce((sum, w) => sum + w.stake, 0);
  const totalWinnings = filteredWagers
    .filter((w) => w.status === "settled" && w.result === "won")
    .reduce((sum, w) => sum + (w.payout - w.stake), 0);

  return (
    <PageTransition>
      <div className="min-h-screen bg-background pb-20 md:pb-0">
        <Header />

        <main className="container py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold mb-6">My Wagers</h1>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-xs text-muted-foreground mb-2">Active Risk</p>
              <p className="font-mono font-bold text-lg">
                ${filteredWagers
                  .filter((w) => w.status === "active")
                  .reduce((sum, w) => sum + w.stake, 0)
                  .toFixed(2)}
              </p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-xs text-muted-foreground mb-2">Max Return</p>
              <p className="font-mono font-bold text-lg text-primary">
                ${filteredWagers
                  .filter((w) => w.status === "active")
                  .reduce((sum, w) => sum + w.payout, 0)
                  .toFixed(2)}
              </p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-xs text-muted-foreground mb-2">Winnings</p>
              <p className={`font-mono font-bold text-lg ${totalWinnings > 0 ? "text-primary" : "text-destructive"}`}>
                ${totalWinnings.toFixed(2)}
              </p>
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-2 mb-6">
            {(["all", "active", "settled", "cancelled"] as const).map((status) => (
              <motion.button
                key={status}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all capitalize ${
                  filterStatus === status
                    ? "bg-primary text-background"
                    : "bg-card border border-border text-foreground hover:border-primary/50"
                }`}
              >
                {status}
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Wagers Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-background/50">
                  <th className="px-6 py-4 text-left text-xs font-semibold text-muted-foreground">
                    Market
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-muted-foreground">
                    Category
                  </th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-muted-foreground">
                    Side
                  </th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-muted-foreground">
                    Stake
                  </th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-muted-foreground">
                    Odds
                  </th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-muted-foreground">
                    P&L
                  </th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-muted-foreground">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredWagers.map((wager, idx) => (
                  <motion.tr
                    key={wager.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="border-b border-border hover:bg-background/50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <p className="font-semibold text-sm">{wager.market}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs font-semibold">
                        {wager.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span
                        className={`font-bold text-sm ${
                          wager.side === "yes" ? "text-primary" : "text-destructive"
                        }`}
                      >
                        {wager.side.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="font-mono font-semibold">
                        ${wager.stake.toFixed(2)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="font-mono font-semibold">
                        {wager.odds.toFixed(2)}x
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        {calculatePnL(wager) > 0 ? (
                          <TrendingUp className="w-4 h-4 text-primary" />
                        ) : calculatePnL(wager) < 0 ? (
                          <TrendingDown className="w-4 h-4 text-destructive" />
                        ) : null}
                        <span
                          className={`font-mono font-bold ${
                            calculatePnL(wager) > 0
                              ? "text-primary"
                              : calculatePnL(wager) < 0
                              ? "text-destructive"
                              : "text-muted-foreground"
                          }`}
                        >
                          {calculatePnL(wager) > 0 ? "+" : ""}
                          {calculatePnL(wager).toFixed(2)}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span
                        className={`px-2 py-1 rounded text-xs font-semibold capitalize ${
                          wager.status === "active"
                            ? "bg-primary/20 text-primary"
                            : wager.status === "settled"
                            ? wager.result === "won"
                              ? "bg-primary/20 text-primary"
                              : "bg-destructive/20 text-destructive"
                            : "bg-muted/20 text-muted-foreground"
                        }`}
                      >
                        {wager.status}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        </main>

        <BottomNav />
      </div>
    </PageTransition>
  );
}
