import { useState } from "react";
import { motion } from "framer-motion";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import PageTransition from "@/components/PageTransition";
import { ArrowUpRight, ArrowDownLeft, Plus, Minus } from "lucide-react";

interface Transaction {
  id: string;
  type: "deposit" | "withdrawal" | "bet" | "payout";
  description: string;
  amount: number;
  timestamp: string;
  status: "completed" | "pending";
}

const mockTransactions: Transaction[] = [
  {
    id: "1",
    type: "payout",
    description: "Bet Payout - Manchester United Win",
    amount: 450,
    timestamp: "2026-04-20 14:32",
    status: "completed",
  },
  {
    id: "2",
    type: "bet",
    description: "Bet Placed - Bitcoin Price",
    amount: -250,
    timestamp: "2026-04-20 12:15",
    status: "completed",
  },
  {
    id: "3",
    type: "deposit",
    description: "Bank Transfer",
    amount: 1000,
    timestamp: "2026-04-19 10:45",
    status: "completed",
  },
  {
    id: "4",
    type: "withdrawal",
    description: "Withdrawal to Bank",
    amount: -500,
    timestamp: "2026-04-18 16:20",
    status: "completed",
  },
];

export default function Wallet() {
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);

  return (
    <PageTransition>
      <div className="min-h-screen bg-background pb-20 md:pb-0">
        <Header />

        <main className="container py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-3xl font-bold mb-6">Wallet</h1>

            {/* Balance Card */}
            <div className="bg-card border border-border rounded-2xl p-8 mb-8">
              <p className="text-muted-foreground mb-2">Total Balance</p>
              <p className="text-5xl font-bold text-primary font-mono mb-6">
                KSh 1,250.50
              </p>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowDepositModal(true)}
                  className="flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Deposit
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowWithdrawModal(true)}
                  className="flex items-center gap-2 px-6 py-3 border border-border rounded-lg font-semibold hover:bg-popover transition-colors"
                >
                  <Minus className="w-4 h-4" />
                  Withdraw
                </motion.button>
              </div>
            </div>

            {/* Transaction History */}
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              <div className="p-6 border-b border-border">
                <h2 className="text-xl font-semibold">Transaction History</h2>
              </div>

              <div className="divide-y divide-border">
                {mockTransactions.map((tx) => (
                  <motion.div
                    key={tx.id}
                    whileHover={{ backgroundColor: "rgba(201, 168, 76, 0.05)" }}
                    className="p-6 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className={`p-3 rounded-lg ${
                          tx.amount > 0
                            ? "bg-primary/10"
                            : "bg-destructive/10"
                        }`}
                      >
                        {tx.amount > 0 ? (
                          <ArrowDownLeft className="w-5 h-5 text-primary" />
                        ) : (
                          <ArrowUpRight className="w-5 h-5 text-destructive" />
                        )}
                      </div>
                      <div>
                        <p className="font-semibold">{tx.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {tx.timestamp}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p
                        className={`font-mono font-bold ${
                          tx.amount > 0 ? "text-primary" : "text-destructive"
                        }`}
                      >
                        {tx.amount > 0 ? "+" : ""}
                        KSh {Math.abs(tx.amount).toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {tx.status}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </main>

        <BottomNav />
      </div>
    </PageTransition>
  );
}
