import { useState } from "react";
import { motion } from "framer-motion";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import PriceChart from "@/components/PriceChart";
import BetSlip from "@/components/BetSlip";
import PageTransition from "@/components/PageTransition";
import { ArrowLeft, MessageCircle, BarChart3 } from "lucide-react";

const mockChartData = [
  { time: "10:00", price: 1.75 },
  { time: "10:15", price: 1.82 },
  { time: "10:30", price: 1.88 },
  { time: "10:45", price: 1.85 },
  { time: "11:00", price: 1.92 },
  { time: "11:15", price: 1.95 },
  { time: "11:30", price: 2.01 },
  { time: "11:45", price: 1.98 },
];

const mockOrderBook = {
  bids: [
    { price: 1.95, amount: 2500, total: 4875 },
    { price: 1.90, amount: 3200, total: 6080 },
    { price: 1.85, amount: 4100, total: 7585 },
  ],
  asks: [
    { price: 2.05, amount: 1800, total: 3690 },
    { price: 2.10, amount: 2400, total: 5040 },
    { price: 2.15, amount: 3500, total: 7525 },
  ],
};

type TabType = "chart" | "orderbook" | "comments";

export default function MarketDetail() {
  const [activeTab, setActiveTab] = useState<TabType>("chart");

  return (
    <PageTransition>
      <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Header />

      <main className="container py-8">
        {/* Back Button & Market Info */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <button className="flex items-center gap-2 text-primary hover:text-accent transition-colors mb-4">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back to Markets</span>
          </button>

          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs font-semibold">
                  Sports
                </span>
                <span className="text-xs text-destructive font-semibold">LIVE</span>
              </div>
              <h1 className="text-3xl font-bold mb-2">
                Will Manchester United win against Liverpool?
              </h1>
              <p className="text-muted-foreground text-sm">
                Resolves on April 25, 2026 at 3:00 PM UTC
              </p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Tab Navigation */}
            <div className="flex gap-2 border-b border-border pb-4">
              {(["chart", "orderbook", "comments"] as const).map((tab) => (
                <motion.button
                  key={tab}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
                    activeTab === tab
                      ? "bg-primary text-background"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {tab === "chart" && "Chart"}
                  {tab === "orderbook" && "Order Book"}
                  {tab === "comments" && "Comments"}
                </motion.button>
              ))}
            </div>

            {/* Chart Tab */}
            {activeTab === "chart" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <PriceChart data={mockChartData} />
              </motion.div>
            )}

            {/* Order Book Tab */}
            {activeTab === "orderbook" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="space-y-4"
              >
                <div className="grid grid-cols-2 gap-4">
                  {/* Bids */}
                  <div className="bg-card border border-border rounded-lg p-4">
                    <h3 className="font-semibold text-sm mb-4 text-primary">BIDS</h3>
                    <div className="space-y-2">
                      {mockOrderBook.bids.map((bid, idx) => (
                        <div key={idx} className="flex justify-between text-xs">
                          <span className="text-muted-foreground">
                            ${bid.price.toFixed(2)}
                          </span>
                          <span className="font-mono font-semibold">
                            ${bid.amount.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Asks */}
                  <div className="bg-card border border-border rounded-lg p-4">
                    <h3 className="font-semibold text-sm mb-4 text-destructive">ASKS</h3>
                    <div className="space-y-2">
                      {mockOrderBook.asks.map((ask, idx) => (
                        <div key={idx} className="flex justify-between text-xs">
                          <span className="text-muted-foreground">
                            ${ask.price.toFixed(2)}
                          </span>
                          <span className="font-mono font-semibold">
                            ${ask.amount.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Comments Tab */}
            {activeTab === "comments" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="bg-card border border-border rounded-lg p-6"
              >
                <div className="text-center py-12">
                  <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                  <p className="text-muted-foreground">Comments coming soon...</p>
                </div>
              </motion.div>
            )}

            {/* Market Metadata */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs text-muted-foreground mb-2">Total Volume</p>
                <p className="font-mono font-bold text-lg text-primary">$125.0K</p>
              </div>
              <div className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs text-muted-foreground mb-2">Liquidity</p>
                <p className="font-mono font-bold text-lg text-accent">$45.2K</p>
              </div>
              <div className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs text-muted-foreground mb-2">Participants</p>
                <p className="font-mono font-bold text-lg">2,847</p>
              </div>
            </div>
          </div>

          {/* Bet Slip Sidebar */}
          <div className="lg:col-span-1">
            <BetSlip
              onBet={(stake, mode) => {
                console.log(`Placed ${stake} USD bet in ${mode} mode`);
              }}
            />
          </div>
        </div>
      </main>

        <BottomNav />
      </div>
    </PageTransition>
  );
}
