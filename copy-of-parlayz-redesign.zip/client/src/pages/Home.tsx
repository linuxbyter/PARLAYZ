import { useState } from "react";
import { motion } from "framer-motion";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import SidebarDrawer from "@/components/SidebarDrawer";
import MarketCard from "@/components/MarketCard";
import PageTransition from "@/components/PageTransition";
import { ChevronDown } from "lucide-react";

const mockMarkets = [
  {
    id: 1,
    type: "binary" as const,
    title: "Will Manchester United win against Liverpool?",
    category: "Sports",
    volume: 125000,
    odds: { yes: 1.85, no: 2.15 },
    priceChange: 2.5,
    isLive: true,
  },
  {
    id: 2,
    type: "binary" as const,
    title: "Will Bitcoin reach $100k by end of Q2?",
    category: "Crypto",
    volume: 450000,
    odds: { yes: 1.65, no: 2.45 },
    priceChange: -1.2,
    isLive: true,
  },
  {
    id: 3,
    type: "multi" as const,
    title: "Who will win the 2026 World Cup?",
    category: "Sports",
    volume: 320000,
    options: [
      { label: "France", percentage: 28 },
      { label: "Brazil", percentage: 25 },
      { label: "Argentina", percentage: 22 },
      { label: "Other", percentage: 25 },
    ],
    priceChange: 3.1,
    isLive: true,
  },
  {
    id: 4,
    type: "duel" as const,
    title: "Ronaldo vs Messi: Most goals in 2026?",
    category: "Sports",
    volume: 85000,
    duelInfo: { player1: "Ronaldo", player2: "Messi" },
    priceChange: 0,
    isLive: false,
  },
  {
    id: 5,
    type: "binary" as const,
    title: "Will Ethereum flip Bitcoin by market cap?",
    category: "Crypto",
    volume: 210000,
    odds: { yes: 2.1, no: 1.8 },
    priceChange: 1.8,
    isLive: true,
  },
  {
    id: 6,
    type: "multi" as const,
    title: "Which party will win Kenya's 2027 election?",
    category: "Politics",
    volume: 95000,
    options: [
      { label: "Party A", percentage: 35 },
      { label: "Party B", percentage: 40 },
      { label: "Party C", percentage: 25 },
    ],
    priceChange: -2.3,
    isLive: true,
  },
];

const categories = ["All", "Sports", "Crypto", "Politics", "Tech", "Meme"];

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredMarkets = mockMarkets.filter(
    (market) => selectedCategory === "All" || market.category === selectedCategory
  );

  return (
    <PageTransition>
      <div className="min-h-screen bg-background flex flex-col">
        <Header />
        {/* Category Navigation */}    <div className="sticky top-16 z-40 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container py-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 -mb-2">
            {categories.map((cat) => (
              <motion.button
                key={cat}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-lg font-semibold text-sm whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border text-foreground hover:border-primary/40"
                }`}
              >
                {cat}
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Markets Grid */}
      <main className="container py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Active Markets</h1>
          <motion.button
            whileHover={{ scale: 1.05 }}
            className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors"
          >
            <span className="text-sm">Sort by</span>
            <ChevronDown className="w-4 h-4" />
          </motion.button>
        </div>

        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredMarkets.map((market, idx) => (
            <motion.div
              key={market.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
            >
              <MarketCard
                type={market.type}
                title={market.title}
                category={market.category}
                volume={market.volume}
                odds={market.odds}
                options={market.options}
                duelInfo={market.duelInfo}
                priceChange={market.priceChange}
                isLive={market.isLive}
                onClick={() => {
                  // Navigate to market detail page
                  window.location.href = `/market/${market.id}`;
                }}
              />
            </motion.div>
          ))}
        </motion.div>

        {filteredMarkets.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <p className="text-muted-foreground">No markets found in this category.</p>
          </motion.div>
        )}
      </main>

        <BottomNav />
        <SidebarDrawer />
      </div>
    </PageTransition>
  );
}
