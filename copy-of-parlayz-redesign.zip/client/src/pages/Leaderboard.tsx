import { useState } from "react";
import { motion } from "framer-motion";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import PageTransition from "@/components/PageTransition";
import { Trophy, TrendingUp } from "lucide-react";

interface LeaderboardEntry {
  rank: number;
  name: string;
  profit: number;
  winRate: number;
  volume: number;
  trades: number;
}

const mockLeaderboard: LeaderboardEntry[] = [
  {
    rank: 1,
    name: "CryptoKing",
    profit: 45230,
    winRate: 68.5,
    volume: 125000,
    trades: 342,
  },
  {
    rank: 2,
    name: "MarketMaster",
    profit: 38920,
    winRate: 65.2,
    volume: 98500,
    trades: 287,
  },
  {
    rank: 3,
    name: "PredictionPro",
    profit: 32150,
    winRate: 62.8,
    volume: 87200,
    trades: 256,
  },
  {
    rank: 4,
    name: "TradeWizard",
    profit: 28450,
    winRate: 61.3,
    volume: 76800,
    trades: 234,
  },
  {
    rank: 5,
    name: "BetBoss",
    profit: 24680,
    winRate: 59.7,
    volume: 65400,
    trades: 198,
  },
];

type SortBy = "profit" | "winRate" | "volume";

export default function Leaderboard() {
  const [sortBy, setSortBy] = useState<SortBy>("profit");

  const sorted = [...mockLeaderboard].sort((a, b) => {
    if (sortBy === "profit") return b.profit - a.profit;
    if (sortBy === "winRate") return b.winRate - a.winRate;
    return b.volume - a.volume;
  });

  return (
    <PageTransition>
      <div className="min-h-screen bg-background pb-20 md:pb-0">
        <Header />

        <main className="container py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <Trophy className="w-8 h-8 text-primary" />
              <h1 className="text-3xl font-bold">Leaderboard</h1>
            </div>

            {/* Sort Buttons */}
            <div className="flex gap-2 mb-6">
              {(["profit", "winRate", "volume"] as const).map((sort) => (
                <motion.button
                  key={sort}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSortBy(sort)}
                  className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                    sortBy === sort
                      ? "bg-primary text-primary-foreground"
                      : "bg-card border border-border hover:border-primary/40"
                  }`}
                >
                  {sort === "profit"
                    ? "Profit"
                    : sort === "winRate"
                      ? "Win Rate"
                      : "Volume"}
                </motion.button>
              ))}
            </div>

            {/* Leaderboard Table */}
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border bg-popover/50">
                      <th className="px-6 py-4 text-left text-sm font-semibold text-muted-foreground">
                        Rank
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-muted-foreground">
                        Player
                      </th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-muted-foreground">
                        Profit
                      </th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-muted-foreground">
                        Win Rate
                      </th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-muted-foreground">
                        Volume
                      </th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-muted-foreground">
                        Trades
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {sorted.map((entry, idx) => (
                      <motion.tr
                        key={entry.rank}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        whileHover={{ backgroundColor: "rgba(201, 168, 76, 0.05)" }}
                        className="transition-colors"
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            {entry.rank <= 3 && (
                              <Trophy
                                className={`w-4 h-4 ${
                                  entry.rank === 1
                                    ? "text-yellow-500"
                                    : entry.rank === 2
                                      ? "text-gray-400"
                                      : "text-orange-400"
                                }`}
                              />
                            )}
                            <span className="font-bold text-primary">
                              #{entry.rank}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 font-semibold">{entry.name}</td>
                        <td className="px-6 py-4 text-right">
                          <span className="font-mono font-bold text-primary">
                            KSh {entry.profit.toLocaleString()}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <TrendingUp className="w-4 h-4 text-primary" />
                            <span className="font-semibold">
                              {entry.winRate.toFixed(1)}%
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right font-mono">
                          KSh {(entry.volume / 1000).toFixed(0)}k
                        </td>
                        <td className="px-6 py-4 text-right text-muted-foreground">
                          {entry.trades}
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        </main>

        <BottomNav />
      </div>
    </PageTransition>
  );
}
