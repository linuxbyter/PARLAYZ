import { createContext, useContext, useState, ReactNode } from "react";

interface AppContextType {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  userBalance: number;
  setUserBalance: (balance: number) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userBalance, setUserBalance] = useState(1250.5);

  return (
    <AppContext.Provider
      value={{
        sidebarOpen,
        setSidebarOpen,
        userBalance,
        setUserBalance,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within AppProvider");
  }
  return context;
}
