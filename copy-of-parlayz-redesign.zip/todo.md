# Parlayz Prediction Markets Redesign

## Design System
- [x] Update color palette: warm gold/brown (#C9A84C, #D4AF37, #8B6914) with dark warm browns
- [x] Update typography: Geist for UI, JetBrains Mono for numbers
- [x] Implement minimalistic card styling with warm inner shadows
- [x] Update global CSS variables and Tailwind theme
- [x] Add generous spacing and breathing room to cards

## Core Features
- [x] Persistent header with category navigation (Sports, Crypto, Politics, Tech, Meme)
- [x] Wallet balance display and user avatar
- [x] Market card variants: Binary, Multi-outcome, Head-to-Head Duel
- [x] Market detail page with price chart and tabs

## Betting Pools - Correct Implementation
- [x] Fixed Odds pool mode (traditional bookmaker style)
- [x] Peer-to-Peer pool mode (parimutuel: users bet against each other, prices set by crowd)
- [x] Mini Pools feature:
  - [x] Create mini pool: name, member limit (up to 10), initial stake
  - [x] Generate shareable link for mini pool
  - [x] Join mini pool: accept invite, select side, enter stake
  - [x] Display pool members and their stakes
  - [x] Mini pool payout calculation (proportional to side stakes, minus 3% fee)

## Bet Slip Component
- [x] Redesign with new color palette
- [x] Implement three pool mode selection
- [x] Stake input validation ($0.01 - $10,000)
- [x] Payout calculator for each pool type
- [x] Floating particles animation on bet placement

## Pages & Features
- [x] Home feed with market cards (new styling)
- [x] Market detail page (new styling, P2P mechanics)
- [x] My Wagers page (active, settled, cancelled bets)
- [x] Wallet page (balance, deposit, withdraw, history)
- [x] Leaderboard page (profit, win rate, volume)
- [x] Mobile responsive design (bottom nav, sidebar drawer)

## Animations & Polish
- [x] Card hover effects with warm glow
- [x] Page transitions
- [x] Micro-interactions throughout
- [x] Floating particles on bet placement
- [x] Smooth scrolling and transitions

## Testing & Deployment
- [x] Component tests for Bet Slip and Mini Pool flows
- [x] Integration tests for betting flows
- [x] Responsive design validation
- [x] Performance optimization
- [x] Final polish and refinement

## Implementation Enhancements
- [x] Wire Header mobile menu to SidebarDrawer with AppContext
- [x] Replace hardcoded wallet balance with AppContext state
- [x] Implement warm glow hover effects on market cards
- [x] Add PageTransition component for route-level animations
- [x] Add smooth scrolling behavior to HTML
- [x] Update all pages with PageTransition wrapper
- [x] Create AppContext for shared state management
- [x] Implement Mini Pool manager component
