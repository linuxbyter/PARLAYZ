import "@testing-library/jest-dom";
import "vitest-dom";

declare module "vitest" {
  interface Assertion<T = any> extends CustomMatchers<T> {}
  interface AsymmetricMatchersContaining extends CustomMatchers {}
}

interface CustomMatchers<R = void> {
  toBeInTheDocument(): R;
  toHaveClass(className: string): R;
  toBeVisible(): R;
  toBeDisabled(): R;
  toBeEnabled(): R;
}
